import heapq
from collections import Counter

def huffman(text):
    freq = Counter(text)

    heap = [[f, [ch, ""]] for ch, f in freq.items()]
    heapq.heapify(heap)

    while len(heap) > 1:
        left = heapq.heappop(heap)
        right = heapq.heappop(heap)

        for item in left[1:]:
            item[1] = "0" + item[1]

        for item in right[1:]:
            item[1] = "1" + item[1]

        heapq.heappush(heap, [left[0] + right[0]] + left[1:] + right[1:])

    codes = heap[0][1:]

    print("\nHuffman Codes:")
    for ch, code in codes:
        print(ch, ":", code)

    print("\nEncoded String:")
    code_dict = dict(codes)
    print("".join(code_dict[ch] for ch in text))


text = input("Enter a string: ")
huffman(text)