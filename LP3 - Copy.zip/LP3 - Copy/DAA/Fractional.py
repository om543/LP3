def fractional_knapsack(capacity, items):
    items.sort(key=lambda x: x[1] / x[0], reverse=True)

    total_profit = 0

    for weight, profit in items:
        if capacity >= weight:
            capacity -= weight
            total_profit += profit
        else:
            total_profit += profit * (capacity / weight)
            break

    print("Maximum Profit:", total_profit)


# Main Program
n = int(input("Enter number of items: "))

items = []

for i in range(n):
    weight = int(input("Enter weight: "))
    profit = int(input("Enter profit: "))
    items.append((weight, profit))

capacity = int(input("Enter knapsack capacity: "))

fractional_knapsack(capacity, items)