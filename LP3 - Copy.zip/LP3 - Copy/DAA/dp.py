def knapsack(capacity, weights, profits, n):
    dp = [[0 for x in range(capacity + 1)] for x in range(n + 1)]

    for i in range(1, n + 1):
        for w in range(1, capacity + 1):

            if weights[i-1] <= w:
                dp[i][w] = max(
                    profits[i-1] + dp[i-1][w-weights[i-1]],
                    dp[i-1][w]
                )
            else:
                dp[i][w] = dp[i-1][w]

    print("Maximum Profit:", dp[n][capacity])


# Main Program
n = int(input("Enter number of items: "))

weights = []
profits = []

for i in range(n):
    weights.append(int(input("Enter weight: ")))
    profits.append(int(input("Enter profit: ")))

capacity = int(input("Enter knapsack capacity: "))

knapsack(capacity, weights, profits, n)